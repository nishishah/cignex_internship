package Person_Package;

public class Person
{
	double Id;
	double Phone_no;
	char Gender;
	int Age;
	String Name;
	String Address;
	String Bloodgroup;
	String DOB;	
	String City;
	void Person()
	{
		/*Id=0.0;
		Phone_no=0.0;
		*/
	}
}
/*
public class Patient extends Person
{
	String TypeOfAid;
	int Room_no;
	String Date;
	void Patient(){}
}

public class Doctor extends Person
{
	String Qualification;
    String Speciality;
    String Timings;
	void Doctor(){}
}

*/
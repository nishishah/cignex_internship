package Inherited_Package;
import Person_Package.*;



public class Patient extends Person
{
	String TypeOfAid;
	int Room_no;
	String Date;
	void Patient(){}
}


package Inherited_Package;
import Person_Package.*;


public class Doctor extends Person
{
	String Qualification;
    String Speciality;
    String Timings;
	void Doctor(){}
}

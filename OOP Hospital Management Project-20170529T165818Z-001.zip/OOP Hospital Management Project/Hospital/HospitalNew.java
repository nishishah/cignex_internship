//package Hospital;

//import Inherited_Packages.*;
import java.io.*;
import java.util.*;
import java.lang.*;

class Person implements Serializable
{
	double Id;
	double Phone_no;
	char Gender;
	int Age;
	String Name;
	String Address;
	String BloodGroup;
	String DOB;	
	String City;
	public Person()
	{
		Id=0.0;
		Phone_no=0.0;
		Gender='\0';
		Age=0;
		Name=null;
		Address=null;
		BloodGroup=null;
		DOB=null;
		City=null;
	}
}

class Patient extends Person implements Serializable
{
	String TypeOfAid;
	//  int Room_no;			//Try later using randomize function!!
	String Date;
	public Patient()
	{
		super();
		TypeOfAid=null;
		// Room_no=0;
		Date=null;
	}
}

class Doctor extends Person implements Serializable
{
	String Qualification;
    String Speciality;
    String Timings;
	public Doctor()
	{
		super();
		Qualification=null;
		Speciality=null;
		Timings=null;
	}
}

class HospitalNew
{
	public static void main(String args[]) throws Exception 
		{
			Scanner s= new Scanner(System.in);
			int choice;
			System.out.println(".................Hospital................");
			System.out.println("1.Patient Details ");
		    System.out.println("2.Doctor Details ");
			System.out.println("3.Patient Report ");
			System.out.println("4.Exit ");
			System.out.println("\nEnter your choice:");
			choice=s.nextInt();
			switch(choice)
			{
				case 1:
				int ch;
				System.out.println(".....Patient.....");
				System.out.println("1.New Patient Entry");
				System.out.println("2.Existing Patient");
				System.out.println("3.Previous Menu");                 //Add Delete Option!
				System.out.println("\nEnter your choice");
				ch=s.nextInt();
				switch(ch)
				{
					case 1:
					String fileName;
					//System.out.println("\nEnter File Name: ");
					fileName = "Patient.txt";	
	
					FileOutputStream fout = null;
					ObjectOutputStream oOut = null;
					try
					{
				
					fout = new FileOutputStream(fileName , true);
					oOut = new ObjectOutputStream(fout);
					
					do
					{
					Patient P = new Patient();
					System.out.println("Enter the details of the patient : ");
					System.out.println("Enter Patient Id");
					P.Id = s.nextDouble();
					System.out.println("Enter Patient Contact Number");
					P.Phone_no = s.nextDouble();
					System.out.println("Gender:");
					P.Gender = s.next().charAt(0);
					System.out.println("Age:");
					P.Age = s.nextInt();
					System.out.println("Patient Name:");
					P.Name = s.nextLine();
					P.Name = s.nextLine();
					System.out.println("Patient Address:");
					P.Address = s.nextLine();
					System.out.println("Patient Blood Group:");
					P.BloodGroup = s.nextLine();
					System.out.println("DOB:");
					P.DOB = s.nextLine();
					System.out.println("City:");
					P.City = s.nextLine();
					System.out.println("Enter the type of Aid required and its description: ");
					P.TypeOfAid = s.nextLine();
					System.out.println("Enter the date of admission of the patient(DD/MM/YYYY) :");
					P.Date=s.nextLine();

					oOut.writeObject(P);
					oOut.flush();
					
					System.out.println("\nEnter 1 to continue adding");
					choice=s.nextInt();
					}while(choice==1);
					}
					catch(IOException e)
					{
						System.out.println("Error" +e);
					}
					finally
					{
						oOut.close();
					}

					break;
					
					case 2:
					break;
					case 3:
					break;
				}
				break;
				case 2:

				String fileName;
				//System.out.println("\nEnter File Name: ");
				fileName = "Doctor.txt";	

				FileOutputStream fout = null;
				ObjectOutputStream oOut = null;
				try
				{
				
					fout = new FileOutputStream(fileName , true);
					oOut = new ObjectOutputStream(fout);
					
					do
					{
					Doctor D = new Doctor();
					System.out.println("Enter the details of Doctor: ");
					System.out.println("Doctor Id:");
					D.Id = s.nextDouble();
					System.out.println("Phone Number:");
					D.Phone_no = s.nextDouble();
					System.out.println("Gender:");
					D.Gender = s.next().charAt(0);
					System.out.println("Age:");
					D.Age = s.nextInt();
					System.out.println("Doctor Name:");
					D.Name = s.nextLine();
					D.Name = s.nextLine();
					System.out.println("Doctor Address:");
					D.Address = s.nextLine();
					System.out.println("Doctor Blood Group:");
					D.BloodGroup = s.nextLine();
					System.out.println("DOB:");
					D.DOB = s.nextLine();
					System.out.println("City:");
					D.City = s.nextLine();
					System.out.println("Doctor Qualification:");
					D.Qualification = s.nextLine();
					System.out.println("Doctor Speciality:");
					D.Speciality = s.nextLine();
					System.out.println("Doctor Timings:");
					D.Timings = s.nextLine();

					oOut.writeObject(D);
					oOut.flush();
					
					System.out.println("\nEnter 1 to continue adding");
					choice=s.nextInt();
					}while(choice==1);
				}		
				catch(IOException e)
				{
					System.out.println("Error" +e);
				}
				finally
				{
					oOut.close();
				}
				break;
				case 3:
				/* Use and call the object of the patient from the Patient.txt and also the doctor object from the Doctor.txt!
					Display the system date on the report!	*/
					
				break;
				case 4:
				return;
				
			}
		}
}